import content

def get_words(category: str, difficulty: str, count=5) -> list:
    """
    get_words
    Fetch a specified amount of word/answer pairs of the specified category from the database.
    Args:
        category (str): The category of the words.
        difficulty (int): The difficulty level of the words.
        count (int): The number of words to fetch.
    Returns:
        list: A list dictionaries containing word/answer pairs. 
        For example:
        [
            {"swedish": "hej", "english": "hello", "hints": ["first hint", "second hint", "third hint"]},
            {"swedish": "tack", "english": "thanks", "hints": ["first hint", "second hint", "third hint"]},
            ...
        ]
    """
    return content.get_words(category, difficulty, count)


def get_times(difficulty: str, count=5) -> list:
    """
    get_times
    Fetch a specified amount of digital time/swedish answer pairs from the database.
    Args:
        difficulty (int): The difficulty level of the times.
        count (int): The number of times to fetch.
    Returns:
        list: A list dictionaries containing digital time/swedish answer pairs. 
        For example:
        [
            {"time": "1:15", "swedish": "kvart över ett"},
            {"time": "1:30", "swedish": "halv två"},
            ...
        ]
    """
    return content.get_times(difficulty, count)

def update_score(username: str, score: int) -> None:
    """
    update_score
    Update the score of a user.
    Args:
        username (str): username of the user
        score (int): score to add
    Returns:
        None
    """
    content.update_score(username, score)
